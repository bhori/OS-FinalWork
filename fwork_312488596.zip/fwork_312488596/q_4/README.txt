In order to run the program you need to run the command 'make' or 'make dir_traversal' that will compile the program 'dir_traversal.c' and call the executable file 'dir_traversal'.
You then need to run the program name with one more parameter which is the name of the directory that you want to scan.
Note that if the directory is not located in the same directory as the program, you must pass the full directory path as an argument.

Running example:
1) make
2) ./dir_traversal dir 	/** 'dir' is the name of the directory

** In order to clean the executable files and the compiled files you can run the command 'make clean'.
