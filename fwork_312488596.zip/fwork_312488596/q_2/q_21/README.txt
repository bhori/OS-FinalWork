In order to run the program you need to run the command 'make' or 'make check_pid' that will compile the program 'check_pid.c' and call the executable file 'check_pid'.
You then need to run the program name with one more parameter (integer) that indicates the ID of the process on which we want to check if it exists.

Running example:
1) make
2)./check_pid 2003

** In order to clean the executable files and the compiled files you can run the command 'make clean'.
